package com.example.demoproj.util;

public class StringUtil {

        public static boolean isEmpty(String str) {
            return str == null || str.length() == 0;
        }
}
