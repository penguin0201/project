package com.example.demoproj.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Tab;

public class MainFrameController {

    @FXML
    private Tab personalinfo;

    @FXML
    private Tab studentinfo;

    @FXML
    private Tab teacherinfo;

}
